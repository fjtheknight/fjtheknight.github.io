import React, {Component} from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.js';
import {Bar} from 'react-chartjs-2';
import {Navbar, NavItem, Nav} from 'react-bootstrap';

class Results extends React.Component{
    state = {
      // appUI
      appUI : {
        labels: ['0', '1', '2', '3', '4'],
        datasets: [
          {
            backgroundColor: 'rgba(75,192,192,1)',
            borderColor: 'rgba(0,0,0,1)',
            borderWidth: 2,
            data: [0, 0, 3, 34, 234]
          }
        ]
      },
      // homeColors
      homeColors : {
        labels: ['Blue', 'Green', 'Red'],
        datasets: [
          {
            backgroundColor: 'rgba(75,192,192,1)',
            borderColor: 'rgba(0,0,0,1)',
            borderWidth: 2,
            data: [3, 2, 4]
          }
        ]
      },
      // gameColors
      gameColors : {
        labels: ['Blue', 'Green', 'Red', 'Yellow', 'White', 'Grey'],
        datasets: [
          {
            backgroundColor: 'rgba(75,192,192,1)',
            borderColor: 'rgba(0,0,0,1)',
            borderWidth: 2,
            data: [2, 0, 3, 5, 2, 1]
          }
        ]
      },


    }

    render() {
        return (
            <div className="Results">
                <div class="container">
                    <h2>Results</h2>
                </div>
                <div class="container">
                            <Bar
                            data={this.state.appUI}
                            options={{
                                title:{
                                display:true,
                                text:'How do you find the app UI in general?',
                                fontSize:20
                                },
                                legend:{
                                display:false,
                                }
                            }}
                            />,
                            <Bar
                            data={this.state.homeColors}
                            options={{
                                title:{
                                display:true,
                                text:'What colors did you not like in about the home page?',
                                fontSize:20
                                },
                                legend:{
                                display:false,
                                }
                            }}
                            />,
                            <Bar
                            data={this.state.gameColors}
                            options={{
                                title:{
                                display:true,
                                text:'What colors did you not like in about the game page?',
                                fontSize:20
                                },
                                legend:{
                                display:false,
                                }
                            }}
                            />
                </div>
            </div>        
            );
    }
}

export default Results;